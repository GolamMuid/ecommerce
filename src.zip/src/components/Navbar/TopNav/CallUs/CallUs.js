import React from 'react'
import { CallUsContainer, CallUsNumber } from './CallUs.style'

function CallUs() {
    return (
        <CallUsContainer>
            call us : <CallUsNumber> +88 02 48953302 </CallUsNumber>
        </CallUsContainer>
    )
}
export default CallUs