import React from 'react'
import LoginRegisterContainer from './LoginRegister.style'

function LoginRegister() {
    return (
        <LoginRegisterContainer>
            Login
        </LoginRegisterContainer>
    )
}

export default LoginRegister