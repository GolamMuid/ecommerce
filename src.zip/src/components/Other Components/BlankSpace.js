import React from 'react'

function BlankSpace() {
    return (
        <div style={{ marginBottom: '110px' }}>
        </div>
    )
}

export default BlankSpace