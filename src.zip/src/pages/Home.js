import React from 'react'
import Navbar from '../components/Navbar/Navbar'
import Text from '../components/Other Components/Text'
import BlankSpace from '../components/Other Components/BlankSpace'
import Footer from '../components/Footer/Footer'
import ScrollToTop from '../components/Other Components/ScrollToTop'
import CategoryAndBanners from '../components/HomepageFirstPart/CategoryAndBanners'
import Slider from '../components/HomepageFirstPart/SearchAndBanner/Slider/Slider'
import TopCategories from '../components/top categories/TopCategories'

function Home() {
    return (
        <>
            <Navbar />
            <BlankSpace />
            <CategoryAndBanners />
            <TopCategories />
            <Footer />
            <ScrollToTop />
        </>
    )
}

export default Home