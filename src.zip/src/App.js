import GlobalStyle from "./components/Other Components/GlobalStyle";
import Home from "./pages/Home";
import { ThemeProvider } from "styled-components";
import ScrollToTop from "./components/Other Components/ScrollToTop";

function App() {
  const theme = {
    color: {
      primary: "#404040",
      secondary: "black",
      bg: 'white',
      bgSecondary: '#dad9d9',
      bgTertiary: "#EFF2F9",
      invertedPrimary: 'white',
      invertedBg: 'black',
      borderPrimary: '#EBEBEB'
    }
  }

  return (
    <div>
      <ThemeProvider theme={theme}>
        <GlobalStyle />
        <Home />
        <ScrollToTop />
      </ThemeProvider>
    </div>
  );
}

export default App;
